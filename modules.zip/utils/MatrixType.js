

export default class MatrixType {

    
}