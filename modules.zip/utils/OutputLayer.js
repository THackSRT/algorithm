


export default class OutputLayer {
    
}